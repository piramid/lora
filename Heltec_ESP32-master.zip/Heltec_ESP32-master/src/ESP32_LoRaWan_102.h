#if !defined(HT_DE01)&&!defined(WIFI_Kit_32)&&!defined(WIFI_Kit_32_V3)
#ifndef __LORAWAN_102_H__
#define __LORAWAN_102_H__

#include "loramac/LoRaMac.h"
#include "loramac/Commissioning.h"
#include "loramac/region/Region.h"

#endif

#endif