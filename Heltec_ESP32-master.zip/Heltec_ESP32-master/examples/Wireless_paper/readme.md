1.Modifying the program

​		<img src="img/image-1.png"/>

Connect to WiFi.

Compile and burn programs

2.After initialization is completed, access the wireless_paper IP address, which can be viewed on the serial port

![Alt text](img/image.png)

3.The following page appears![](img/image-2.png)Click![](img/image-3.png) Select an image, and to ensure a refresh effect, it is best to choose a black and white BMP format image. The image size should be set to 250 x 122.

The button will display the file address, as shown in the picture![](img/image-4.png)

4.Click the Get image data button to obtain image data, which will be displayed on the canvas. The effect is as follows:![](img/image-5.png)
5.Click the refresh button to refresh the image on the ink screen.

