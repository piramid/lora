#define WiFi_Logo_width 250
#define WiFi_Logo_height 122
 uint8_t WiFi_Logo_bits[10000] PROGMEM = {
};
