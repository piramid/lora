# LoRaBasic Folder

All examples in this path, just directly call the SX1262 hardware layer to transmit LoRa signals, and do not include any operations with protocol layer.